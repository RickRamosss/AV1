package com.example.ibge.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

@SpringBootApplication(scanBasePackages = {"com.example"})
@EnableMongoRepositories("com.example.ibge.repository")
public class IbgeApplication {

	public static void main(String[] args) {
		SpringApplication.run(IbgeApplication.class, args);
	}

}
