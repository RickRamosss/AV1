package com.example.ibge.repository;

import com.example.ibge.model.IbgeEntity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IbgeRepository extends MongoRepository<IbgeEntity,String> {

}
